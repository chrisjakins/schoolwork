#include <string>
#include "puzzle.h"

Puzzle::Puzzle(std::string solution) 
    : _solution{solution}, _guesses{}
    { }

static bool inString(char c, std::string phrase) {
    for (unsigned int i = 0; i < phrase.length(); i++) {
        if (c == phrase[i]) {
            return true;
        }
    }
    return false;
}

bool Puzzle::guess(unsigned char c) {
    if (c < 'a' || c > 'z' || _guesses[c]) throw Bad_input{};
    _guesses[c] = true;
    return inString(c, _solution);
}

bool Puzzle::solve(std::string proposed_solution) {
    /* compare method returns '0' if equal so
       '!' makes function return true if equal */
    return !_solution.compare(proposed_solution);
}

std::string Puzzle::to_string() {
    std::string user_view = _solution;
    for (unsigned int i = 0; i < user_view.length(); i++) {
        if (!_guesses[static_cast<unsigned>(user_view[i])] && user_view[i] != ' ') {
            user_view[i] = '_';
        }
    }
    return user_view;
}

std::string Puzzle::get_solution() {
    return _solution;
}
