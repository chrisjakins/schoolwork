/* Chris Jakins */
/* CSE1325 */
/* HW3 9/14 */
#include <iostream>
#include <string>
#include "puzzle.h"
#include "fuse.h"

void welcome();
bool attempt_solve(Puzzle);
std::string get_answer();
void end_message(bool, std::string);
bool isOver(Puzzle);

int main() {
    std::string final_answer = get_answer(), user_in;
    Puzzle game{final_answer};
    Fuse fuse{(int)game.get_solution().length() + 1};
    unsigned char user_guess;
    bool winner = false, exit = false;

    welcome();

    while (!exit) {
        std::cout << fuse.to_string() << game.to_string() << ": ";
        getline(std::cin, user_in);
        user_guess = user_in[0];
        switch(user_guess)
        {
            case '!':
                winner = attempt_solve(game); 
            case '0':
                exit = true;
                break;
            default:
                try {
                    if (!game.guess(user_guess)) {
                        if (fuse.burn() == 0) {
                            exit = true;
                        }
                    }
                    if (game.solve(game.to_string())) {
                        winner = true;
                        exit = true;
                    }
                } catch (Bad_input e) {
                    std::cerr << "Invalid input...\n"
                              << "Enter a character from a to z\n";
                }
                break;
        }
    }
    
    end_message(winner, game.get_solution()); 
    return 0;
}

bool attempt_solve(Puzzle game) {
    std::string user_solution;
    std::cout << "Enter your proposed solution: ";
    getline(std::cin, user_solution);
    return game.solve(user_solution);
}

std::string get_answer() {
    std::string answer;
    std::cout << "Enter the hidden phrase: ";
    getline(std::cin, answer);
    for (int i = 0; i < 80; i++) {
        std::cout << '\n';
    }
    return answer;
}

bool isOver(Puzzle current_game) {
    /* compare method returns '0' if equal 
       so '!' makes function return true
       if equal */
    return !current_game.get_solution().compare(current_game.to_string());
}

void welcome() {
    std::cout << "\t================\n" 
              << "\t    B O O M !\n"
              << "\t================\n" 
              << std::endl;
    std::cout << "Enter lower case leters to guess,\n" 
              << "! to propose a solution,\n" 
              << "0 to exit."
              << std::endl;
}

void end_message(bool won, std::string answer) {
    if (won) {
        std::cout << "*** W I N N E R ***\n";
    } else {
        std::cout << "##### B O O M #####\n";
    }
        std::cout << "The answer was: " << answer << std::endl;
}
