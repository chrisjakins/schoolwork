#include <string>
#include "fuse.h"

Fuse::Fuse(int time)
    : _time{time} 
    {  }

bool Fuse::burn() {
    return --_time;
}

std::string Fuse::to_string() {
    std::string firecracker = "    ";
    for (int i = 1; i < _time; i++) {
        firecracker += '_';
    }
    firecracker += "*\n   /\n,+,\n| |\n|_|\n";

    return firecracker;
}
