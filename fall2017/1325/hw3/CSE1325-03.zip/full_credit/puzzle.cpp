#include <string>
#include "puzzle.h"

Puzzle::Puzzle(std::string solution) 
    : _solution{solution}, _guesses{}
    { }

bool Puzzle::guess(unsigned char c) {
    if (_guesses[c]) {
        return false;
    }
    _guesses[c] = true;
    return true;
}

bool Puzzle::solve(std::string proposed_solution) {
    if (_solution.compare(proposed_solution)) {
        return false;
    }
    return true;
}

std::string Puzzle::to_string() {
    std::string user_view = _solution;
    for (unsigned int i = 0; i < user_view.length(); i++) {
        if (!_guesses[static_cast<unsigned>(user_view[i])] && user_view[i] != ' ') {
            user_view[i] = '_';
        }
    }
    return user_view;
}

std::string Puzzle::get_solution() {
    return _solution;
}
