#include <string>

class Fuse {
    public:
        Fuse(int);
        
        bool burn();
        std::string to_string(); 
    private:
        int _time;
};
