#include <fstream>
#include <string>
#include <vector>
#include <cstdlib>
#include "words.h"

Words::Words(std::string filename) {
    std::fstream in;
    in.open(filename, std::fstream::in);
    if (!in.is_open()) throw Bad_file{};

    std::string word;
    while (in >> word) {
        _words.push_back(word);
    }
}

std::string Words::get_word() {
    srand(time(NULL));
    int index = rand() % _words.size();
    return _words[index];
}
