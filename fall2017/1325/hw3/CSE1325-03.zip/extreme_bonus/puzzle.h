#include <string>
#include <exception>

class Bad_input: public std::exception {};

class Puzzle {
    public:
        Puzzle(std::string);

        bool guess(unsigned char);
        bool solve(std::string);

        std::string to_string();
        std::string get_solution();

    private:
        std::string _solution;
        bool _guesses[255];
};
