#include <string>
#include <vector>
#include <exception>

class Bad_file : public std::exception {};

class Words {
    public:
        Words(std::string);

        std::string get_word();
    private:
        std::vector<std::string> _words;
};
